# 下面的代码是你需要完成的部分：
# 你需要实现 single_line_process 函数，该函数接受两个参数，一个是字符串 input，一个是字符串 line。
# input_str 是一个字符串，line 是一个简单语句。
# 该函数需要返回一个字符串，表示对 input_str 进行 line 指定的操作后的结果。

def single_line_process(input_str, line):
    '''
    @param input_str: str   输入字符串
    @param line: str        简单语句
    @return: str            返回对 input_str 进行 line 指定的操作后的结果
    '''
    ##############################################################
    # 在这里实现你的代码
    ##############################################################
    
    return input_str # 将返回的东西替换为你的计算得到的值

# 你可以使用形如下面的代码来测试你的代码，在这个 `if` 语句中执行的一切操作均不会被评分。
if __name__ == "__main__":
    input_str = "ABC"
    line = "A = B;"
    print(single_line_process(input_str, line)) # BBC