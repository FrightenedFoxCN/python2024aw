lII1Ill1 										,										IllIll11 										,										IIIllIlI                   ,                  I11I1IIl 									,									III111Il 											,											IIll11Il                                ,                               lII1l1II 									,									IIl1l1lI                 ,                II1I111l                   ,                  l11111I1 														,														l11IlllI 										,										III1IIIl 										,										llIl1llI                              ,                             l1ll1ll1 									,									lIlllI11 													,													I1111lll 										,										IllII1Il                              ,                             Il111lII 									,									lI11ll1I                      ,                     l1llII1l 													,													II1lIlIl                              ,                             llI1l1I1                        ,                       l11II1Il 														,														I11llll1 									,									IlIl11II                          ,                         I11llllI 														,														l1lIlIIl 														,														Il111l1l 														,														lllII111 													,													Il11I1Il                 ,                I1I1lIIl                 ,                ll1I1III                          ,                         IIl1I1Il                      ,                     l1lI11ll 											,											II1Il1I1                                ,                               l1l1l1ll 																,																l1lIlI1I                        ,                       I1lIl1II                              ,                             Il111Ill 																,																llI1lIIl 								,								ll11ll1l 											,											l1I1llII 															,															lIIIIl11                         ,                        IlIl1Il1                        ,                       llllIlII                         ,                        l11Il1l1                                ,                               l11I11ll 										,										Il1llII1                  ,                 l111lII1 										,										IlII1111                 ,                Il1II1ll 												,												ll111l1l                               ,                              IIIIll1l 																,																llll111I                       ,                      lIll1I1I 												,												IIIIl1lI 									,									lI1llIlI 												,												II11I111 									,									lIl1III1 										,										Illl1lII                     ,                    I1Ill1l1                       ,                      lIlI1II1 													,													I1lllI1I                       ,                      I11I1IlI                   ,                  IIlI111I                                 ,                                I1l1lI11 													,													llI1lII1 								,								l11l1lII                    =                   															(															721618297 										+										101469738                            ^                                            (                 499181076                         ^                        751809946 												)												                     ,                                       ~                  														-														                     (                     418931656 												^												418931653 												)												                 ,                 															(															289121000                             ^                            155665694 													)													                           +                           															(															282805761                             +                            															-															693644743                          )                                          ,                 587170953 																-																263246221                               ^                                                      ~                        															-															323924719                                ,                                                               ~                                                           -                           351133900 												+												                     -                     																~																												-												351133862                      ,                                                  (                             299307520 																^																695874775                  )                 														+														                  -                  											(											42313537 											^											975733230 													)													                               ,                               98881572                         +                        180096562                  +                                 -                														~																									-											278978115 													,													';'                        ,                        															~															                  -                                          ~                        													-													13 									,									707305721                           +                          146829192                       ^                      								(								584004735                           ^                          270935265 								)								                            ,                                                   ~                       															(															111826158 								+																						-														111826193                 )                								,								103005894 											^											510450459 												^												437267911                  +                                            -                           29411323                      ,                     															~															                            (                            714469294                        +                                       -                714469320 								)								                   ,                   'Syntax error: missing semicolon at the end of line: '																,																1568290 										-										                         -                         898718676                      ^                     181035492                          -                         																-																719251457                          ,                         782352263                    -                   										-										96345603 													^																											~																											-													878697859                 ,                                       ~                       																-																564535688 														^																													(															536391185                                 ^                                1046384543                            )                           										,										                       (                       587280342                     ^                    351611178                          )                         										+										                 -                 										(										995721694 								^								212698887 								)																						,														len 								,								                        ~                        																-																                        (                        387516496                  ^                 387516488 																)																                       ,                       									(									793431593                        ^                       1034041876 									)																					+																								(												234923300 								-								552180063                  )                                           ,                          											~																								-													666993027 										+										                (                450317889                            +                                                 -                      1117310912                        )                                                 ,                          372517170 															+																												-													131347011 											^																					(										846387333 													^													1009593958                 )                                         ,                         									~									                 -                 800272087                             +                            																-																										(										937075333                         ^                        409570353                 )                											,											327861941                             ^                            1068430717 											^											141435176 												-												                  -                  599134908 													,													479732304                           ^                          524591836                   ^                  								~								                -                64782505 										,										                    ~                                        -                    												~																					-									27                             ,                                                            ~                                                              -                              545021346                         ^                                                (                        486217916                          ^                         1015498046 														)														                  ,                  564060389 											^											327341866 															^																								(									543802615 															^															309719864                              )                                                           ,                              								~																					-													165440581 															+																											-												                                ~                                                  -                  165440539                            ,                                               (                    257606853 												^												278879048 														)																									-											                              (                              229320044                 ^                309246513                               )                                                     ,                       																(																324870677 										^										830650633 									)									                           +                           											-											                       ~                       														-														585079574 											,											186406233                                 -                                                    -                    364533279                  ^                                      (                     434886549 								^								960330944                         )                        												,												114483644 														-														                 -                 377503700 																+																															-															                          (                          790860351 												^												846246737 														)																										,																					(									733112301                        ^                       331876701 																)																												+																									-													                           (                           658200521                        ^                       524368196 											)											                         ,                         82407609                  ^                 9235062                       ^                      106617761 												+																								-												32850119 										,										                    (                    324037044 								^								48528023 															)															                -                                  (                  386827590                       +                                      -                89813589 																)																								,								                       (                       89105405                     ^                    369363876 														)														                            -                            															(															383453760 															+															                -                59728393                         )                                                     ,                             													(													191702461 										^										299697529 																)																                           -                                              (                   350650029                       ^                      240541235                               )                              									,									159565061                      +                     527541327 												-												                    (                    677697470 											-											                           -                           9408897 										)										                               ,                               653883601 								-								                             -                             313432811                        +                       								(								812990373                            -                           1780306746 										)																									,															518646675                                 -                                374445365 								-								                  (                  30568774                         +                        113632493 															)																							,								75347127                                 ^                                323685608 													^													                              ~                              														-														389462137                     ,                    283774110                          -                         													-													137276826 											+											                   -                   																(																793721798 														^														911704546                               )                              								,								                  ~                  												-												551016386 									^																		(									317497077                               ^                              842746135                      )                                                    ,                                                   ~                                                  -                                                         (                           500605233 																^																500605210                     )                                               ,                                                           ~                                                       -                                               (                        454817673                   ^                  454817710                              )                             								,																				(												127822689                   ^                  705231969 															)															                       +                       										-																					(											767621118 															^															5660932                            )                                            ,                 '='                            ,                            603963238 											+											318151643 									^									499715944 													-																									-												422398955 																,																                  ~                  								-								687053987 														-																									(											726015869 											+											                    -                    38961884                    )                   								,								529036990                   +                                        -                      304950940 									^																		(									518357813                  ^                 331270932 												)																									,													815417341                             ^                            618640776                    ^                   													(													573669382                              ^                             913601124                        )                                            ,                     50263404 														-														                     -                     77375049 											^																							(												739395835 										^										730452805 										)																			,									                     ~                     										-										957309015                  -                 									~																							-														957308991                    ,                   788028904 																^																164229244 											^																										(															386636258 									^									809120873                   )                                                 ,                               541782969                           +                                               -                     487924076                  ^                 132009336 															+																														-															78150433 														,														40810586                  -                                  -                 86212452 																^																                         (                         536285709                   ^                  409281980 														)														                       ,                       717750641                        ^                       823967614 								^								401239187                    -                                                  -                               65687930                             ,                            												~												                              -                              380188160 																+																                           -                                                       (                            711872263                          ^                         1019706105 														)																											,																						~									                          -                          											(											314265044                          ^                         314265026 											)											                                ,                                								~								                         -                                                       (                              404348065                        ^                       404348076                 )                								,								                 ~                 									-									935836285                         +                        								(								223992485                                 -                                1159828762 													)																													,																													~																						-									502011359 														^														25985600                          -                         												-												476025777 														,														694139088                     +                    																-																622728612                  -                 														(														421220643 													^													492499933 													)																								,																										(															108735322                      ^                     385023971                      )                                        +                                    -                 									~																	-								277468330 										,										940856290                        +                                        -                 872623569 											^																					(										265407408 										^										197193133 													)													                               ,                               'Syntax error: missing equal sign in line: '												)												



def lI11lI1I 											(											lIlIlIll 											)											                        :                        

													return True 









def I111lIlI 								(								lIlIlIll                         )                        																:																


													return lIlIlIll 
I111IlIl 														=														lambda IIl11ll1                              :                             True 


II11l1ll 														=														lambda IIl11ll1 									:									IIl11ll1 






class l1IIl111 										:										


													@														staticmethod 








													def ll11IlI1                                 (                                Ill1IlIl                            )                                                   :                        




																										return True 








													@                              staticmethod 


													def I1l1ll1I 															(															Ill1IlIl 																)																														:														



																										return Ill1IlIl 







def llI1Ill1                             (                            I1lll1ll 													,													lII1l1l1 												)																										:														









													try 															:															




																										return I1lll1ll                         !=                        lII1l1l1 





													except 										:										
																										return not I1lll1ll                            ==                           lII1l1l1 







def lll1llIl 															(															I11II1ll 												,												III11Ill                           )                          								:								









													lII1II11 														=														I1l1lI11 



													lllll11l 											=											llI1l1I1 



													if not I1111lll 											:											


																										lllll11l                    =                   Il11I1Il 




													else                  :                 

																										lllll11l                             =                            IIl1I1Il 

													if lllll11l                     ==                    IIl1I1Il 										:										








																										if not I11II1ll                   .                  endswith                 (                IIl1l1lI                    )                                               :                            
																																							lllll11l                                 =                                Il11I1Il 







																										else                           :                          


																																							lllll11l 													=													Illl1lII 
													if lllll11l 													==													Illl1lII                          :                         






																										lII1II11 								=								I1Ill1l1 



													if lllll11l                       ==                      l11Il1l1                                 :                                









																										lII1II11 								=								IIl1I1Il 





													if lII1II11                                 ==                                lII1Ill1 											:											


																										l1IIl1lI 										=										IllII1Il 



																										if not lI11lI1I                               (                              III1IIIl 											)											                  :                  




																																							l1IIl1lI 										=										I1I1lIIl 





																										else                      :                     









																																							l1IIl1lI                             =                            lIll1I1I 



																										if l1IIl1lI                           ==                          lIll1I1I                                 :                                








																																							if not lI11lI1I 															(															IIIIll1l                         )                        									:									








																																																				l1IIl1lI 									=									II11I111 


																																							else                      :                     





																																																				l1IIl1lI                              =                             I1I1lIIl 

																										if l1IIl1lI 									==									I1I1lIIl 															:															

																																							lII1II11 										=										II1I111l 






																										if l1IIl1lI 													==													II11I111                      :                     









																																							lII1II11                        =                       I1Ill1l1 

													if lII1II11 																==																l1l1l1ll                        :                       

																										pass 







													if lII1II11 								==								llll111I                               :                              








																										raise Exception 											(											l1ll1ll1                           +                          I11II1ll                  )                 









													I11II1ll                              =                             I11II1ll 													[													                           :                                                 -                      Illl1lII 								]								






													lI111llI                             =                            lIlI1II1 









													II1lIlII 																=																llI1lIIl 







													if not I11I1IlI 								:								
																										II1lIlII                          =                         llIl1llI 









													else 									:									



																										II1lIlII                           =                          IIl1I1Il 

													if II1lIlII 												==												IIl1I1Il                             :                            





																										if not lI11lI1I 																(																III111Il 														)														                            :                            






																																							II1lIlII 								=								l1lIlIIl 









																										else 								:								


																																							II1lIlII                                 =                                IIIIl1lI 

													if II1lIlII                         ==                        llIl1llI 													:													







																										lI111llI                         =                        ll111l1l 









													if II1lIlII                          ==                         IIIIl1lI 												:												

																										lI111llI 												=												IIIllIlI 









													if lI111llI 									==									I1I1lIIl                               :                              









																										lll111lI 									=									lI1llIlI 

																										if l111lII1 in I11II1ll                                 :                                







																																							lll111lI 										=										l1lIlI1I 



																										else 								:								



																																							lll111lI 															=															IllIll11 


																										if lll111lI 								==								IllIll11                         :                        








																																							if not l1IIl111                           .                          ll11IlI1                           (                          I1l1lI11                           )                                             :                   



																																																				lll111lI 															=															l1lIlI1I 








																																							else 																:																
																																																				lll111lI                    =                   Il111l1l 







																										if lll111lI                      ==                     Il111lII                   :                  









																																							lI111llI 										=										llI1l1I1 









																										if lll111lI 													==													l1lIlI1I 												:												



																																							lI111llI                               =                              Il1llII1 





													if lI111llI 												==												Il1llII1 										:										

																										pass 





													if lI111llI 								==								llI1l1I1 													:													

																										raise Exception 															(															l11l1lII                   +                  I11II1ll 										)										









													IIlI1IlI 															,															I1Il11ll 																=																I11II1ll 																.																split                            (                           l111lII1 										)										




													IIlI1IlI 										=										IIlI1IlI 									.									strip 												(																				)								


													I1Il11ll                 =                I1Il11ll                          .                         strip 													(																													)																







													l1l11ll1 												=												l11111I1 







													lIIIl1Il 									=									lIlllI11 









													if not l1IIl111                 .                ll11IlI1 											(											I1I1lIIl                    )                                      :                   








																										lIIIl1Il 										=										IlII1111 





													else 															:															






																										lIIIl1Il                            =                           IIIIll1l 








													if lIIIl1Il 															==															IIIIll1l 														:														








																										if not l1lI11ll                     :                    







																																							lIIIl1Il 												=												II1lIlIl 





																										else                        :                       
																																							lIIIl1Il                         =                        I11I1IIl 








													if lIIIl1Il 														==														I11I1IIl                      :                     
																										l1l11ll1 															=															lII1Ill1 








													if lIIIl1Il 									==									II1lIlIl 									:									







																										l1l11ll1                         =                        l11II1Il 



													if l1l11ll1                    ==                   IIl1I1Il 								:								









																										lllI1III                               =                              l1lI11ll 









																										if not I111IlIl 													(													II1I111l 															)															                          :                          





																																							lllI1III                      =                     lIIIIl11 




																										else                   :                  
																																							lllI1III 															=															l11I11ll 





																										if lllI1III                      ==                     III111Il                              :                             
																																							if not llI1Ill1                  (                 lI11ll1I 													(													IIlI1IlI                           )                                                    ,                          lllII111                          )                                              :                     









																																																				lllI1III 																=																lIIIIl11 






																																							else 																:																






																																																				lllI1III                               =                              IIlI111I 


																										if lllI1III                                 ==                                ll11ll1l                  :                 









																																							l1l11ll1 																=																llI1lII1 




																										if lllI1III 										==										IIlI111I                    :                   






																																							l1l11ll1                     =                    l1llII1l 









													if l1l11ll1                                ==                               l11II1Il 									:									






																										return I1Il11ll 										+										III11Ill 







													if l1l11ll1 																==																l1llII1l                  :                 







																										pass 

													ll111III 																=																lIll1I1I 


													II1lI1II                      =                     l1I1llII 









													if not lIl1III1                       :                      





																										II1lI1II 															=															lII1l1II 




													else 												:												
																										II1lI1II 											=											Il111Ill 

													if II1lI1II                        ==                       Il111Ill 												:												







																										if not IlIl11II 															:															
																																							II1lI1II                     =                    IlIl1Il1 








																										else                                :                               





																																							II1lI1II                       =                      I1l1lI11 




													if II1lI1II 															==															IlIl1Il1                       :                      


																										ll111III                  =                 I1lIl1II 




													if II1lI1II                               ==                              I1l1lI11 											:											



																										ll111III                 =                llllIlII 



													if ll111III 									==									II1Il1I1 									:									
																										lIlI1llI 															=															ll1I1III 


																										if not I11llllI                         :                        




																																							lIlI1llI                        =                       IIll11Il 






																										else 													:													





																																							lIlI1llI                             =                            l11IlllI 








																										if lIlI1llI 													==													l11IlllI                              :                             




																																							if IIlI1IlI in III11Ill 															:															

																																																				lIlI1llI                              =                             I11I1IlI 






																																							else 															:															







																																																				lIlI1llI                 =                IIll11Il 





																										if lIlI1llI 										==										I11I1IlI                            :                           
																																							ll111III                  =                 I1lllI1I 


																										if lIlI1llI                       ==                      IIll11Il 											:											









																																							ll111III                     =                    I11llll1 





													if ll111III                          ==                         l11IlllI                               :                              








																										return III11Ill 




													if ll111III 												==												ll1I1III 								:								


																										return III11Ill 													.													replace 															(															IIlI1IlI                         ,                        I1Il11ll                             ,                            Il1II1ll 														)														




def single_line_process_baseline                                (                               input 												,												line                       )                      											:											









													return lll1llIl                 (                line 												,												input                     )                    