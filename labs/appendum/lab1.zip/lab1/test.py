import unittest
import random
from problem import single_line_process
from baseline import single_line_process_baseline

def generate_input_string(length):
    return ''.join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ", k=length))

def generate_line_string(length1, length2):
    return ''.join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ", k=length1)) \
            + " = " \
            + ''.join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ", k=length2)) + ";"

def generate_testcase():
    input_length = random.randint(0, 20)
    input = generate_input_string(input_length)
    line = generate_line_string(random.randint(0, input_length), random.randint(0, input_length))
    return input, line

class SinglelineTest(unittest.TestCase):

    def test_singleline_basic(self):
        self.assertEqual(single_line_process("ABC", "A = B;"), "BBC")

    def test_singleline_multiple_occurences(self):
        self.assertEqual(single_line_process("AAC", "A = B;"), "BAC")

    def test_singleline_no_occurences(self):
        self.assertEqual(single_line_process("ABC", "D = E;"), "ABC")
    
    def test_singleline_multiple_char(self):
        self.assertEqual(single_line_process("ABC", "AB = CD;"), "CDC")
    
    def test_singleline_multiple_char_multiple_occurences(self):
        self.assertEqual(single_line_process("ABACAB", "AB = CDE;"), "CDEACAB")

    def test_singleline_multiple_char_no_occurences(self):
        self.assertEqual(single_line_process("AACB", "AB = CDE;"), "AACB")

    def test_singleline_empty_source(self):
        self.assertEqual(single_line_process("ABC", "= B;"), "BABC")
    
    def test_singleline_empty_target(self):
        self.assertEqual(single_line_process("ABC", "A = ;"), "BC")

class SinglelineRandomTest(unittest.TestCase):
    def test_with_baseline(self):
        for _ in range(1000):
            input, line = generate_testcase()
            self.assertEqual(single_line_process(input, line), single_line_process_baseline(input, line))

if __name__ == '__main__':
    text_loader = unittest.TestLoader()
    basic_tests = text_loader.loadTestsFromTestCase(SinglelineTest)
    result = unittest.TextTestRunner(failfast=True).run(basic_tests)
    if result.wasSuccessful():
        random_tests = text_loader.loadTestsFromTestCase(SinglelineRandomTest)
        unittest.TextTestRunner().run(random_tests)