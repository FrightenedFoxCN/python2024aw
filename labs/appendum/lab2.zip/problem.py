def single_line_process(input_str, line):
    '''
    @param input_str: str   输入字符串
    @param line: str        简单语句
    @return: str            返回对 input_str 进行 line 指定的操作后的结果
    '''
    ##############################################################
    # 在这里实现你的代码
    ##############################################################
    
    return input_str, True # 将返回的东西替换为你的计算得到的值

def main_loop(input_str, line):
    '''
    @param input_str: str   输入字符串
    @param line: str        多行语句
    @return: str            返回对 input_str 进行 line 指定的操作后的结果
    '''
    ##############################################################
    # 在这里实现你的代码
    ##############################################################
    
    return input_str # 将返回的东西替换为你的计算得到的值