import unittest
import random
from problem import main_loop

def generate_input_string(letter_range, length):
    return ''.join(random.choices(letter_range, k=length))

class PalindroneTest(unittest.TestCase):
    def __init__(self, runTest):
        super().__init__(runTest)
        self.lines = "A = B;" # 请在这里填入你编写的字符串程序

    def is_palindrone(self, input_str):
        return "true" if input_str == input_str[::-1] else "false"
    
    def test_most_letter(self):
        for _ in range(1000):
            test_case_input = generate_input_string("ABC", random.choice([i * 2 + 1 for i in range(1, 20)]))
            with self.subTest(test_case_input=test_case_input):
                self.assertEqual(main_loop(test_case_input, self.lines), self.is_palindrone(test_case_input))

if __name__ == '__main__':
    unittest.main(failfast=True)