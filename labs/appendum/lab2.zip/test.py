import unittest
import random
from problem import main_loop

def generate_input_string(letter_range, length):
    return ''.join(random.choices(letter_range, k=length))

class HelloworldTest(unittest.TestCase):
    def __init__(self, runTest):
        super().__init__(runTest)
        self.lines = "B = A; C = A; AA = A; A = helloworld;"
    
    def test_helloworld(self):
        for _ in range(1000):
            test_case_input = generate_input_string("ABC", random.randint(1, 20))
            with self.subTest(test_case_input=test_case_input):
                self.assertEqual(main_loop(test_case_input, self.lines), "helloworld")

class SortTest(unittest.TestCase): 
    def __init__(self, runTest):
        super().__init__(runTest)
        self.lines = "BA = AB; CA = AC; CB = BC;"
    
    def sort(self, input_str):
        return ''.join(sorted(input_str))
        
    def test_sort(self):
        for _ in range(1000):
            test_case_input = generate_input_string("ABC", random.randint(1, 20))
            with self.subTest(test_case_input=test_case_input):
                self.assertEqual(main_loop(test_case_input, self.lines), self.sort(test_case_input))

class MostLetterTest(unittest.TestCase):
    def __init__(self, runTest):
        super().__init__(runTest)
        self.lines = "BA = AB; ABB = B; AAB = A; AA = A; BB = B;"

    def most_letter(self, input_str):
        count_a = input_str.count("A")
        count_b = input_str.count("B")
        if count_a > count_b:
            return "A"
        else:
            return "B"
    
    def test_most_letter(self):
        for _ in range(1000):
            test_case_input = generate_input_string("AB", random.choice([i * 2 + 1 for i in range(1, 20)]))
            with self.subTest(test_case_input=test_case_input):
                self.assertEqual(main_loop(test_case_input, self.lines), self.most_letter(test_case_input))

if __name__ == '__main__':
    unittest.main(failfast=True)